import docx

doc = docx.Document()
doc.save("Word文件範例.docx")
