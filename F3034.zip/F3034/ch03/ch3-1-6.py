with open("note.txt", "r") as fp:
    str1 = fp.read()
    print("檔案內容:")
    print(str1)    
    