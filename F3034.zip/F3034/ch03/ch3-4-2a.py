import random as R

value = R.randint(1, 100)
print(value)
