fp = open("temp\\note.txt", "w")
if fp != None:
    print("檔案開啟成功!")
fp.close()    
