import random

print(dir(random))

