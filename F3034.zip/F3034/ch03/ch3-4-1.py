import mybmi
 
mybmi.name = "陳會安"
print("姓名=", mybmi.name)
r = mybmi.bmi(1.75, 75)
print("BMI值=", r)

