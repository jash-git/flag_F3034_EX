fp = open("note.dat", "wb")
if fp != None:
    print("二進位檔案開啟成功!")
fp.close() 
   