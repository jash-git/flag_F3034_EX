from mybmi import *
 
name = "陳會安"
print("姓名 = " + name)
r = bmi(1.75, 75)
print("BMI值 = " + str(r))
