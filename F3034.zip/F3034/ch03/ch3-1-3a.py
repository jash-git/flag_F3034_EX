fp = open("temp/note.txt", "a")
fp.write("陳允傑")
print("已經新增1個姓名到檔案note.txt!")
fp.close()

    