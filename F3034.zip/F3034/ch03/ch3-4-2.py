import random

value = random.randint(1, 100)
print(value)
