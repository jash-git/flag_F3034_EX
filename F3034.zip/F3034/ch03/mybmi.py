name = None

def bmi(h, w):
    r = w/h/h
    return r

