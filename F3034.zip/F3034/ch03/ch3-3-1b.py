lst1 = [1, 2, 3, 4, 5]
try:
    print(lst1[6])
except IndexError:
    print("錯誤: 串列的索引值錯誤!") 
    
    