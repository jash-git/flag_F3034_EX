m = 10
eval("print('Python')")
eval("print(33 + 22)")
eval("print(55 / 9)")
eval("print('m' * 6)")
eval("print(m+10)")

    