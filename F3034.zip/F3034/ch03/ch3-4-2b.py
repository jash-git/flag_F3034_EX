from mybmi import bmi
 
r = bmi(1.75, 75)
print("BMI值=", r)

