import shutil

s_path = "./jpgs"
d_path = "./figures"
shutil.copytree(s_path, d_path)  
