import shutil

path = "./figures"
shutil.rmtree(path)  
