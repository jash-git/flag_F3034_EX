from pathlib import Path

path = Path("temp/ball0.jpg")
print(path.exists())

path = Path("examples/圖片1")
print(path.exists())
