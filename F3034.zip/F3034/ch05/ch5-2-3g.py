import shutil

path = "./videos"
shutil.move(path+"/video1.mp4", "./img")  
shutil.move(path, "./img/a")  
