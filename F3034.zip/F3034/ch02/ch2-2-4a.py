lst1 = [4, 2, 8, 9, 1, 8]
print("lst1 = " + str(lst1))
s = lst1.count(8)
print("lst1.count(8) = " + str(s))
s = lst1.index(8)
print("lst1.index(8) = " + str(s))
s = lst1.index(1)
print("lst1.index(1) = " + str(s))
lst1.sort()
print("lst1.sort() = " + str(lst1))
lst1.reverse()
print("lst1.reverse() = " + str(lst1))

