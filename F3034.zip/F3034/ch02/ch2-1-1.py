str1 = "Python自動化" 
name1 = str("陳會安")
print("str1 = " + str1)
print(name1)
