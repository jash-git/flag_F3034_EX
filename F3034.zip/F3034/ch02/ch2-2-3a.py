lst1 = [1, 5]
lst1.extend([7, 9, 11, 13])
print(lst1)
