lst1 = [1, 5]
lst1.append(7)
print(lst1)
lst1.append(9)
print(lst1)
