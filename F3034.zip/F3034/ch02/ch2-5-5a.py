lst1 = list('Hello World!')
print("lst1 = " + str(lst1))
s = lst1[1:3]
print("lst1[1:3] = " + str(s))
s = lst1[1:5]
print("lst1[1:5] = " + str(s))
s = lst1[:7]
print("lst1[:7] = " + str(s))
s = lst1[4:]
print("lst1[4:] = " + str(s))
s = lst1[1:-1]
print("lst1[1:-1] = " + str(s))
s = lst1[6:-2]
print("lst1[6:-2] = " + str(s))

