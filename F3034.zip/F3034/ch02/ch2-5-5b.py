t1 = tuple('Hello World!')
print("t1 = " + str(t1))
s = t1[1:3]
print("t1[1:3] = " + str(s))
s = t1[1:5]
print("t1[1:5] = " + str(s))
s = t1[:7]
print("t1[:7] = " + str(s))
s = t1[4:]
print("t1[4:] = " + str(s))
s = t1[1:-1]
print("t1[1:-1] = " + str(s))
s = t1[6:-2]
print("t1[6:-2] = " + str(s))


