d1 = {"chicken": 2, "dog": 4, "cat":3}
for animal, legs in d1.items():
    print("動物:", animal, "/腳:", legs, "隻")
    