str1 = str("Python程式設計")
print(str1[0])
print(str1[1])
print(str1[-1])
print(str1[-2])

