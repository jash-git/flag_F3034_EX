lst1 = [1, 2, 3, 4, 5]
lst2 = [1, 'Python', 5.5]
lst3 = list(["tom", "mary", "joe"])
lst4 = list("python")
print(lst1)
print(lst2, lst3, lst4)

