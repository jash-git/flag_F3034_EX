lst1 = [1, 3, 5, 7, 9, 11, 13]
del lst1[2]
print(lst1)
del lst1[4]
print(lst1)

