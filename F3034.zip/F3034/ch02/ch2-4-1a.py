d1 = {
    "name": "joe",
    1: [2, 4, 6],
    "grade": {
              "english":80,
              "math":78
             }
    }
print(d1)

