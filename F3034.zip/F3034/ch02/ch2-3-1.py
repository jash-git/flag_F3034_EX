t1 = (1, 2, 3, 4, 5)
t2 = (1, 'Joe', 5.5)
t3 = tuple(["tom", "mary", "joe"])
t4 = tuple("python")
print(t1)
print(t2, t3)
print("t4 = " + str(t4))

