d1 = {1: 'apple', 2: 'ball'}
d2 = dict([(1, "tom"), (2, "mary"), (3, "john")])
print(d1)
print("d2 = " + str(d2))
