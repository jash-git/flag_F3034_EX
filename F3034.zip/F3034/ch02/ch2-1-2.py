str1 = "自動化操作" 
for ch in str1:
    print(ch, end=" ")

