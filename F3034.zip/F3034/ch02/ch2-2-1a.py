lst1 = [1, ["tom", "mary", "joe"], [3, 4, 5]]
print(lst1)
print("lst1:" + str(lst1))
