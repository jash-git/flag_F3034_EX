str1 = 'Hello World!'
print("str1 = " + str1)
s = str1[1:3]
print("str1[1:3] = " + s)
s = str1[1:5]
print("str1[1:5] = " + s)
s = str1[:7]
print("str1[:7] = " + s)
s = str1[4:]
print("str1[4:] = " + s)
s = str1[1:-1]
print("str1[1:-1] = " + s)
s = str1[6:-2]
print("str1[6:-2] = " + s)

