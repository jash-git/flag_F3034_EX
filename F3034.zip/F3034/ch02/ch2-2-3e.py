lst1 = [1, 3, 5, 7, 9, 11, 13]
lst1.remove(9)
print(lst1)
lst1.remove(4)
print(lst1)
