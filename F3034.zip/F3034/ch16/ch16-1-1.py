import matplotlib.pyplot as plt

data = [-1, -4.3, 15, 21, 31]
plt.plot(data)  # x軸是 0,1,2,3,4
plt.show()

