x = 5
y = 6
if x == 5:
    print("X大")
else:
    print("X小")
