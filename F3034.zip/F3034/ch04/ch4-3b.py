height = float(input("請輸入您的身高（公分）：")) / 100
weight = float(input("請輸入您的體重（公斤）："))
BMI = weight / (height ** 2)
print("您的BMI值為：", BMI)
