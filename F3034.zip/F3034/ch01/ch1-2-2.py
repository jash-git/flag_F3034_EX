score1 = 35
score2 = 10
score3 = 10
score2 = 27
score3 = score2
print("第一季 = ", score1)
print("第二季 = ", score2)
print("第三季 = ", score3)
