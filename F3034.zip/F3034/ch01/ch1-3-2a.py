# 擁有1個參數的range()函數
for i in range(5):
    print("range(5)的值 = " + str(i))
for i in range(10):
    print("range(10)的值 = " + str(i))
for i in range(11):
    print("range(11)的值 = " + str(i))
# 擁有2個參數的range()函數
for i in range(1, 5):
    print("range(1,5)的值 = " + str(i))
for i in range(1, 10):
    print("range(1,10)的值 = " + str(i))
for i in range(1, 11):
    print("range(1,11)的值 = " + str(i))
# 擁有3個參數的range()函數
for i in range(1, 11, 2):
    print("range(1,11,2)的值 = " + str(i))
for i in range(1, 11, 3):
    print("range(1,11,3)的值 = " + str(i))
for i in range(1, 11, 4):
    print("range(1,11,4)的值 = " + str(i))
for i in range(0, -10, -1):
    print("range(0,-10,-1)的值 = " + str(i))
for i in range(0, -10, -2):
    print("range(0,-10,-2)的值 = " + str(i))
    
    
    
    
    
    





