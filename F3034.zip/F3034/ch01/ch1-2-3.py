a = 6 + 7 
b = a - 2
c = a * b
d = 10 / 3
print("6 + 7 = ", a)
print("a - 2 = ", b)
print("a * b = ", c)
print("10 / 3 = ", d)
