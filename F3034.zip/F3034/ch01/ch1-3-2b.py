m = int(input("請輸入階層數 =>"))
r = 1
n = 1
while n <= m:
    r = r * n
    n = n + 1
print("階層值! = " + str(r))

