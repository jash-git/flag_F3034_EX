a = int(input("請輸入年齡 => "))
if a < 13:
    print("兒童")
elif a < 20:
    print("青少年")
else:
    print("成年人")
