# play()函數的定義
def play():
    print("執行一次自動化")

# main()主程式
def main():
    print("開始做自動化...")
    play()    # 呼叫函數
    print("結束做自動化...")
    
if __name__ == "__main__":
    main()    # 呼叫主程式函數
    
    