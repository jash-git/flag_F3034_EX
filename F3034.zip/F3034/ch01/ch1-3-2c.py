i = 1
  
while True:
    print("第", i, "次")
    i = i + 1
    if i > 5:
        break    # 跳出迴圈
