grade = 76
height = 175.5
weight = 75.5
# 方法一
print("業績分數 = " + str(grade))
print("身高 = " + str(height))
print("體重 = " + str(weight))
# 方法二
print("業績分數 =", grade)
print("身高 =", height)
print("體重 =", weight)