from docx2pdf import convert

# 將Word文件轉換為PDF
convert("各通路業積報告.docx")
