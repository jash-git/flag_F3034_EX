from openpyxl.utils import FORMULAE

print(FORMULAE)




